function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
% function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   g1
%

if T_flag
    T = FENKFP_nonlinear.dynamic_g1_tt(T, y, x, params, steady_state, it_);
end
g1 = zeros(33, 59);
g1(1,15)=params(9)*getPowerDeriv(y(15),params(11),1);
g1(1,16)=(-(T(1)*T(15)));
g1(1,17)=(-((1-y(42))/(1+y(41))*T(2)));
g1(1,41)=(-(T(2)*y(17)*(-(1-y(42)))/((1+y(41))*(1+y(41)))));
g1(1,42)=(-(T(2)*y(17)*(-1)/(1+y(41))));
g1(2,1)=(-(T(3)*T(13)*T(14)));
g1(2,16)=(-(T(3)*T(14)*1/y(1)));
g1(2,18)=1;
g1(2,11)=(-(T(4)*T(24)));
g1(2,41)=(-(T(4)*params(2)/(1+y(11))));
g1(3,19)=(-T(7));
g1(3,48)=(-((-(y(19)*y(47)))/(y(48)*y(48))));
g1(3,47)=(-(y(19)/y(48)));
g1(4,21)=1;
g1(4,7)=(-(T(5)*T(22)*T(23)));
g1(4,36)=(-(T(5)*T(23)*1/y(7)));
g1(4,11)=(-(T(6)*T(25)));
g1(4,41)=(-(T(6)*params(3)/(1+y(11))));
g1(5,48)=(-((-(y(50)*y(49)))/(y(48)*y(48))));
g1(5,49)=(-(y(50)/y(48)));
g1(5,50)=(-(y(49)/y(48)));
g1(6,22)=1;
g1(6,2)=(-((-(1+params(4)*y(23)))/(y(2)*y(2))));
g1(6,23)=(-(params(4)/y(2)));
g1(7,23)=y(24);
g1(7,24)=y(23);
g1(7,25)=(-params(36));
g1(8,20)=y(23)*(-((-(params(4)*y(3)))/(y(20)*y(20))));
g1(8,23)=y(24)-params(4)*y(3)/y(20);
g1(8,3)=y(23)*(-(params(4)/y(20)));
g1(8,24)=y(23);
g1(8,26)=1;
g1(8,27)=(-1);
g1(9,19)=(-T(7));
g1(9,48)=(y(50)-y(19))*T(17);
g1(9,50)=T(7);
g1(9,28)=(-1);
g1(9,47)=(y(50)-y(19))*T(26);
g1(10,19)=(-T(7));
g1(10,48)=(1-y(19))*T(17);
g1(10,47)=(1-y(19))*T(26);
g1(11,30)=1;
g1(11,31)=(-(params(12)/(params(12)-1)/y(32)));
g1(11,32)=(-((-(params(12)/(params(12)-1)*y(31)))/(y(32)*y(32))));
g1(12,48)=(-(y(51)*T(19)));
g1(12,31)=1;
g1(12,51)=(-T(9));
g1(12,33)=(-y(34));
g1(12,34)=(-y(33));
g1(12,47)=(-(y(51)*params(13)*T(8)));
g1(13,48)=(-(y(52)*T(21)));
g1(13,32)=1;
g1(13,52)=(-T(11));
g1(13,34)=(-1);
g1(13,47)=(-(y(52)*params(13)*T(10)));
g1(14,17)=1;
g1(14,33)=(-y(35));
g1(14,35)=(-y(33));
g1(15,16)=1;
g1(15,34)=(-1);
g1(15,36)=1;
g1(15,43)=1;
g1(16,15)=(-y(35));
g1(16,34)=y(37);
g1(16,35)=(-y(15));
g1(16,37)=y(34);
g1(17,20)=(-(y(8)*T(16)));
g1(17,30)=(-((1-params(13))*getPowerDeriv(y(30),(-params(12)),1)));
g1(17,8)=(-T(12));
g1(17,37)=1;
g1(18,20)=(-(params(13)*getPowerDeriv(y(20),params(12)-1,1)));
g1(18,30)=(-((1-params(13))*getPowerDeriv(y(30),1-params(12),1)));
g1(19,23)=y(38);
g1(19,26)=(-1);
g1(19,38)=y(23);
g1(20,24)=(-1);
g1(20,38)=(-1);
g1(20,39)=1;
g1(21,23)=(-y(39));
g1(21,36)=1;
g1(21,39)=(-y(23));
g1(22,10)=(-(params(21)*1/y(10)));
g1(22,40)=1/y(40);
g1(22,55)=(-1);
g1(23,6)=(-(params(22)*1/y(6)));
g1(23,35)=1/y(35);
g1(23,54)=(-1);
g1(24,4)=(-(params(20)*1/y(4)));
g1(24,25)=1/y(25);
g1(24,53)=(-1);
g1(25,29)=1;
g1(26,23)=(-y(38));
g1(26,38)=(-y(23));
g1(26,40)=1;
g1(27,11)=(-params(16));
g1(27,41)=1;
g1(27,56)=(-1);
g1(28,15)=(-(y(17)*(1-params(17))*params(35)));
g1(28,17)=(-(y(15)*(1-params(17))*params(35)));
g1(28,12)=(-params(17));
g1(28,42)=1;
g1(28,57)=(-1);
g1(29,34)=(-((1-params(5))*params(6)/(y(34)*params(6))));
g1(29,13)=(-(params(5)*1/y(13)));
g1(29,43)=1/y(43);
g1(29,58)=(-1);
g1(30,22)=(-(y(2)*y(9)));
g1(30,2)=(-(y(22)*y(9)));
g1(30,5)=1;
g1(30,9)=(-(y(22)*y(2)));
g1(30,44)=1;
g1(31,16)=(-1);
g1(31,36)=(-1);
g1(31,45)=1;
g1(32,19)=1;
g1(32,50)=(-1);
g1(32,46)=1;
g1(33,18)=1/y(14);
g1(33,14)=(-y(18))/(y(14)*y(14));
g1(33,59)=(-exp(x(it_, 7)));

end
