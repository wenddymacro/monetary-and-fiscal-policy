close all;clear all;clc;

load irf4;
load irf5;
load irf6;

% 下面，定位我们需要画出的外生冲击,此处想作生产率冲击e_g的图，
% 因此，我们让程序帮我们找到所有带e_g后缀的变量名
ending_cell={'_e_g'};

% 下面，就开始让程序自动循环作图
for ii=1:length(ending_cell)
    HOR=1:options_.irf;   %这个是脉冲响应时期长度，也就是脉冲响应图的横轴
    var={'y','tc','pi','spread','Q','dif','b','g','re'};        %这个是声明，我们想作出哪些内生变量的脉冲响应图，此处，我想作出产出Y和资本K的图
    figure                %创建图层，开始合并两个内生变量的两个IRFs
    for jj=1:length(var)
        subplot(3,3,jj)
        eval(['irf4.' var{1,jj},ending_cell{1,ii}]);
        eval(['irf5.' var{1,jj},ending_cell{1,ii}]);
        eval(['irf6.' var{1,jj},ending_cell{1,ii}]);
        load irf4
        load irf5
        load irf6
        hold on
        plot(HOR,[eval(['irf4.' var{1,jj},ending_cell{1,ii}])],'-k',HOR,[eval(['irf5.' var{1,jj},ending_cell{1,ii}])],'--r',HOR,[eval(['irf6.' var{1,jj},ending_cell{1,ii}])],'+g','LineWidth',2)
        title([var{1,jj}] )
        legend('平衡预算','债务货币化','央行拆借')   %图例
        grid on
    end
end

figure
Multiplier1=irf4.y_e_g./irf4.g_e_g;
Multiplier2=irf5.y_e_g./irf5.g_e_g;
Multiplier3=irf6.y_e_g./irf6.g_e_g;
plot(HOR,Multiplier1,'-k',HOR,Multiplier2,'--r',HOR,Multiplier3,'+b','LineWidth',2)
ylabel('Multipliers')
legend('平衡预算','债务货币化','央行拆借')   %图例
grid on