function g1 = static_g1(T, y, x, params, T_flag)
% function g1 = static_g1(T, y, x, params, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%                                              to evaluate the model
%   T_flag    boolean                 boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   g1
%

if T_flag
    T = FENKFP_crise.static_g1_tt(T, y, x, params);
end
g1 = zeros(32, 32);
g1(1,1)=params(3);
g1(1,2)=params(2);
g1(1,3)=(-1);
g1(1,28)=1;
g1(1,29)=1;
g1(2,4)=1;
g1(3,4)=(-1);
g1(3,5)=(-1);
g1(3,6)=1;
g1(4,7)=1;
g1(5,8)=1;
g1(5,9)=(-(params(8)/params(28)-1));
g1(6,6)=1;
g1(6,7)=(-1);
g1(6,8)=(-1);
g1(7,9)=1;
g1(7,10)=1;
g1(7,11)=(-1);
g1(8,6)=params(33)*params(29)*T(1);
g1(8,9)=params(29)*params(33)*(1-T(1));
g1(8,10)=params(29)*params(33)-params(33)*params(29)*T(1);
g1(8,12)=params(36);
g1(8,13)=(-params(37));
g1(9,4)=1;
g1(9,5)=(-params(32));
g1(9,6)=(-1);
g1(9,8)=params(28);
g1(9,14)=(-1);
g1(10,5)=(-1);
g1(10,15)=1;
g1(11,16)=1;
g1(11,17)=(-1);
g1(11,18)=1;
g1(12,4)=(-(params(9)*params(1)));
g1(12,6)=(-(params(1)*params(9)*params(7)));
g1(12,17)=1-params(9)*params(1);
g1(12,19)=(-(1-params(9)*params(1)));
g1(12,20)=(-(1-params(9)*params(1)));
g1(13,4)=(-(params(9)*params(1)));
g1(13,6)=(-(params(1)*params(9)*(params(7)-1)));
g1(13,18)=1-params(9)*params(1);
g1(13,20)=(-(1-params(9)*params(1)));
g1(14,3)=1;
g1(14,19)=(-1);
g1(14,21)=(-1);
g1(15,2)=1-params(12);
g1(15,20)=(-1);
g1(15,22)=params(12);
g1(15,30)=1;
g1(16,1)=(-1);
g1(16,20)=1;
g1(16,21)=(-1);
g1(17,23)=1;
g1(18,6)=1;
g1(18,16)=(-((1-params(9))/params(9)));
g1(19,9)=1;
g1(19,12)=(-1);
g1(19,24)=1;
g1(20,10)=(-(params(33)/params(35)));
g1(20,24)=(-(params(34)/params(35)));
g1(20,25)=1;
g1(21,9)=(-1);
g1(21,22)=1;
g1(21,25)=(-1);
g1(22,26)=1-params(20);
g1(23,21)=1-params(18);
g1(24,11)=1-params(19);
g1(25,6)=(-((1-params(15))*params(16)));
g1(25,10)=(-((1-params(15))*params(38)));
g1(25,15)=1-params(15);
g1(25,27)=(-((1-params(15))*params(17)));
g1(26,12)=(-1);
g1(26,26)=1;
g1(27,20)=(-1);
g1(27,27)=1;
g1(27,31)=1;
g1(28,21)=(-((1-params(12))*(1+params(3))/(params(2)+params(3)*(1-params(12)))));
g1(28,31)=1;
g1(29,28)=1-params(21);
g1(30,1)=(-((1-params(22))*params(23)));
g1(30,3)=(-((1-params(22))*params(23)));
g1(30,29)=1-params(22);
g1(31,30)=1;
g1(31,32)=(-1);
g1(32,20)=(-((1-params(24))*params(25)));
g1(32,32)=1-params(24);
if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
end
end
