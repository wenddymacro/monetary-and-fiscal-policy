function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
% function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   g1
%

if T_flag
    T = FENKFP_nonlinear_fm.dynamic_g1_tt(T, y, x, params, steady_state, it_);
end
g1 = zeros(34, 62);
g1(1,15)=params(10)*getPowerDeriv(y(15),params(12),1);
g1(1,16)=(-(T(1)*T(13)));
g1(1,17)=(-((1-y(41))/(1+y(40))*T(2)));
g1(1,40)=(-(T(2)*y(17)*(-(1-y(41)))/((1+y(40))*(1+y(40)))));
g1(1,41)=(-(T(2)*y(17)*(-1)/(1+y(40))));
g1(2,1)=(-(T(3)*T(11)*T(12)));
g1(2,16)=(-(T(3)*T(12)*1/y(1)));
g1(2,18)=1;
g1(2,11)=(-(T(4)*T(21)));
g1(2,40)=(-(T(4)*params(3)/(1+y(11))));
g1(3,49)=(-(y(19)/y(50)));
g1(3,19)=(-T(7));
g1(3,50)=(-((-(y(19)*y(49)))/(y(50)*y(50))));
g1(4,21)=1;
g1(4,7)=(-(T(5)*T(19)*T(20)));
g1(4,35)=(-(T(5)*T(20)*1/y(7)));
g1(4,11)=(-(T(6)*T(22)));
g1(4,40)=(-(T(6)*params(4)/(1+y(11))));
g1(5,50)=(-((-(y(52)*y(51)))/(y(50)*y(50))));
g1(5,51)=(-(y(52)/y(50)));
g1(5,52)=(-(y(51)/y(50)));
g1(6,22)=1;
g1(6,2)=(-((-(1+params(5)*y(23)))/(y(2)*y(2))));
g1(6,23)=(-(params(5)/y(2)));
g1(7,23)=y(24);
g1(7,24)=y(23);
g1(8,20)=y(23)*(-((-(params(5)*y(3)))/(y(20)*y(20))));
g1(8,23)=y(24)-params(5)*y(3)/y(20);
g1(8,3)=y(23)*(-(params(5)/y(20)));
g1(8,24)=y(23);
g1(8,25)=1;
g1(8,26)=(-1);
g1(9,49)=(y(52)-y(19))*T(14);
g1(9,19)=(-T(7));
g1(9,50)=(y(52)-y(19))*T(16);
g1(9,52)=T(7);
g1(9,27)=(-1);
g1(10,49)=(y(28)-y(19))*T(14);
g1(10,19)=(-T(7));
g1(10,50)=(y(28)-y(19))*T(16);
g1(10,28)=T(7);
g1(11,29)=1;
g1(11,30)=(-(params(13)/(params(13)-1)/y(31)));
g1(11,31)=(-((-(params(13)/(params(13)-1)*y(30)))/(y(31)*y(31))));
g1(12,49)=(-(y(53)*params(14)*T(8)));
g1(12,50)=(-(y(53)*y(49)*params(14)*T(17)));
g1(12,30)=1;
g1(12,53)=(-(y(49)*params(14)*T(8)));
g1(12,32)=(-y(33));
g1(12,33)=(-y(32));
g1(13,49)=(-(y(54)*params(14)*T(9)));
g1(13,50)=(-(y(54)*y(49)*params(14)*T(18)));
g1(13,31)=1;
g1(13,54)=(-(y(49)*params(14)*T(9)));
g1(13,33)=(-1);
g1(14,17)=1;
g1(14,32)=(-y(34));
g1(14,34)=(-y(32));
g1(15,16)=1;
g1(15,33)=(-1);
g1(15,35)=1;
g1(15,42)=1;
g1(16,15)=(-y(34));
g1(16,33)=y(36);
g1(16,34)=(-y(15));
g1(16,36)=y(33);
g1(17,20)=(-(y(8)*T(15)));
g1(17,29)=(-((1-params(14))*getPowerDeriv(y(29),(-params(13)),1)));
g1(17,8)=(-T(10));
g1(17,36)=1;
g1(18,20)=(-(params(14)*getPowerDeriv(y(20),params(13)-1,1)));
g1(18,29)=(-((1-params(14))*getPowerDeriv(y(29),1-params(13),1)));
g1(19,23)=y(9);
g1(19,25)=(-1);
g1(19,9)=y(23);
g1(19,44)=y(45);
g1(19,45)=y(44);
g1(20,14)=(-((-(1+params(5)*y(45)))/(y(14)*y(14))));
g1(20,45)=(-(params(5)/y(14)));
g1(20,46)=1;
g1(21,28)=(-1);
g1(21,56)=1;
g1(22,24)=(-1);
g1(22,37)=(-1);
g1(22,38)=1;
g1(23,23)=(-y(38));
g1(23,35)=1;
g1(23,38)=(-y(23));
g1(24,10)=(-(params(22)*1/y(10)));
g1(24,39)=1/y(39);
g1(24,59)=(-1);
g1(25,6)=(-(params(23)*1/y(6)));
g1(25,34)=1/y(34);
g1(25,58)=(-1);
g1(26,20)=(-((1-params(24))*params(25)));
g1(26,5)=(-params(24));
g1(26,28)=1;
g1(26,33)=(-((1-params(24))*params(26)));
g1(26,57)=(-1);
g1(27,25)=(-1);
g1(27,39)=1;
g1(28,11)=(-params(17));
g1(28,40)=1;
g1(28,60)=(-1);
g1(29,15)=(-(y(17)*(1-params(18))*params(36)));
g1(29,17)=(-(y(15)*(1-params(18))*params(36)));
g1(29,12)=(-params(18));
g1(29,41)=1;
g1(29,61)=(-1);
g1(30,33)=(-((1-params(6))*params(7)/(y(33)*params(7))));
g1(30,13)=(-(params(6)*1/y(13)));
g1(30,42)=1/y(42);
g1(30,62)=(-1);
g1(31,15)=(-(y(41)*y(17)));
g1(31,16)=(-y(40));
g1(31,17)=(-(y(15)*y(41)));
g1(31,20)=(-(y(44)*y(45)*y(46)))/(y(20)*y(20))+(-(params(5)*y(44)))/(y(20)*y(20));
g1(31,35)=(-y(40));
g1(31,40)=(-(y(16)+y(35)));
g1(31,41)=(-(y(15)*y(17)));
g1(31,42)=1;
g1(31,43)=(-1);
g1(31,44)=params(5)/y(20)+y(45)*y(46)/y(20);
g1(31,55)=(-1);
g1(31,45)=y(44)*y(46)/y(20);
g1(31,46)=y(45)*y(44)/y(20);
g1(32,22)=(-(y(2)*y(9)));
g1(32,2)=(-(y(22)*y(9)));
g1(32,4)=y(5);
g1(32,5)=y(4);
g1(32,9)=(-(y(22)*y(2)));
g1(32,43)=1;
g1(32,44)=(-(y(46)*y(14)));
g1(32,14)=(-(y(44)*y(46)));
g1(32,46)=(-(y(44)*y(14)));
g1(33,16)=(-1);
g1(33,35)=(-1);
g1(33,47)=1;
g1(34,19)=1;
g1(34,52)=(-1);
g1(34,48)=1;

end
