function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
% function g1 = dynamic_g1(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   g1
%

if T_flag
    T = FENKFP_nonlinear_zlb.dynamic_g1_tt(T, y, x, params, steady_state, it_);
end
g1 = zeros(35, 65);
g1(1,17)=params(9)*getPowerDeriv(y(17),params(11),1);
g1(1,18)=(-(T(1)*T(13)));
g1(1,19)=(-((1-y(44))/(1+y(43))*T(2)));
g1(1,43)=(-(T(2)*y(19)*(-(1-y(44)))/((1+y(43))*(1+y(43)))));
g1(1,44)=(-(T(2)*y(19)*(-1)/(1+y(43))));
g1(2,1)=(-(T(3)*T(11)*T(12)));
g1(2,18)=(-(T(3)*T(12)*1/y(1)));
g1(2,20)=1;
g1(2,12)=(-(T(4)*T(21)));
g1(2,43)=(-(T(4)*params(2)/(1+y(12))));
g1(3,52)=(-(y(21)/y(53)));
g1(3,21)=(-T(7));
g1(3,53)=(-((-(y(21)*y(52)))/(y(53)*y(53))));
g1(4,23)=1;
g1(4,8)=(-(T(5)*T(19)*T(20)));
g1(4,38)=(-(T(5)*T(20)*1/y(8)));
g1(4,12)=(-(T(6)*T(22)));
g1(4,43)=(-(T(6)*params(3)/(1+y(12))));
g1(5,53)=(-((-(y(55)*y(54)))/(y(53)*y(53))));
g1(5,54)=(-(y(55)/y(53)));
g1(5,55)=(-(y(54)/y(53)));
g1(6,24)=1;
g1(6,2)=(-((-(1+params(4)*y(25)))/(y(2)*y(2))));
g1(6,25)=(-(params(4)/y(2)));
g1(7,25)=y(26);
g1(7,26)=y(25);
g1(7,27)=(-params(36));
g1(8,22)=y(25)*(-((-(params(4)*y(3)))/(y(22)*y(22))));
g1(8,25)=y(26)-params(4)*y(3)/y(22);
g1(8,3)=y(25)*(-(params(4)/y(22)));
g1(8,26)=y(25);
g1(8,28)=1;
g1(8,29)=(-1);
g1(9,52)=(y(55)-y(21))*T(14);
g1(9,21)=(-T(7));
g1(9,53)=(y(55)-y(21))*T(16);
g1(9,55)=T(7);
g1(9,30)=(-1);
g1(10,52)=(y(31)-y(21))*T(14);
g1(10,21)=(-T(7));
g1(10,53)=(y(31)-y(21))*T(16);
g1(10,31)=T(7);
g1(11,32)=1;
g1(11,33)=(-(params(12)/(params(12)-1)/y(34)));
g1(11,34)=(-((-(params(12)/(params(12)-1)*y(33)))/(y(34)*y(34))));
g1(12,52)=(-(y(56)*params(13)*T(8)));
g1(12,53)=(-(y(56)*y(52)*params(13)*T(17)));
g1(12,33)=1;
g1(12,56)=(-(y(52)*params(13)*T(8)));
g1(12,35)=(-y(36));
g1(12,36)=(-y(35));
g1(13,52)=(-(y(57)*params(13)*T(9)));
g1(13,53)=(-(y(57)*y(52)*params(13)*T(18)));
g1(13,34)=1;
g1(13,57)=(-(y(52)*params(13)*T(9)));
g1(13,36)=(-1);
g1(14,19)=1;
g1(14,35)=(-y(37));
g1(14,37)=(-y(35));
g1(15,18)=1;
g1(15,36)=(-1);
g1(15,38)=1;
g1(15,45)=1;
g1(16,17)=(-y(37));
g1(16,36)=y(39);
g1(16,37)=(-y(17));
g1(16,39)=y(36);
g1(17,22)=(-(y(9)*T(15)));
g1(17,32)=(-((1-params(13))*getPowerDeriv(y(32),(-params(12)),1)));
g1(17,9)=(-T(10));
g1(17,39)=1;
g1(18,22)=(-(params(13)*getPowerDeriv(y(22),params(12)-1,1)));
g1(18,32)=(-((1-params(13))*getPowerDeriv(y(32),1-params(12),1)));
g1(19,25)=y(10);
g1(19,28)=(-1);
g1(19,10)=y(25);
g1(19,47)=y(48);
g1(19,48)=y(47);
g1(20,16)=(-((-(1+params(4)*y(48)))/(y(16)*y(16))));
g1(20,48)=(-(params(4)/y(16)));
g1(20,49)=1;
g1(21,31)=(-1);
g1(21,58)=1;
g1(22,26)=(-1);
g1(22,40)=(-1);
g1(22,41)=1;
g1(23,25)=(-y(41));
g1(23,38)=1;
g1(23,41)=(-y(25));
g1(24,11)=(-(params(21)*1/y(11)));
g1(24,42)=1/y(42);
g1(24,62)=(-1);
g1(25,7)=(-(params(22)*1/y(7)));
g1(25,37)=1/y(37);
g1(25,61)=(-1);
g1(26,4)=(-(params(20)*1/y(4)));
g1(26,27)=1/y(27);
g1(26,60)=(-1);
g1(27,22)=(-((1-params(23))*params(24)));
g1(27,6)=(-params(23));
g1(27,31)=1;
g1(27,36)=(-((1-params(23))*params(25)));
g1(27,59)=(-1);
g1(28,28)=(-1);
g1(28,42)=1;
g1(29,12)=(-params(16));
g1(29,43)=1;
g1(29,63)=(-1);
g1(30,17)=(-(y(19)*(1-params(17))*params(35)));
g1(30,19)=(-(y(17)*(1-params(17))*params(35)));
g1(30,13)=(-params(17));
g1(30,44)=1;
g1(30,64)=(-1);
g1(31,36)=(-((1-params(5))*params(6)/(y(36)*params(6))));
g1(31,14)=(-(params(5)*1/y(14)));
g1(31,45)=1/y(45);
g1(31,65)=(-1);
g1(32,17)=(-(y(44)*y(19)));
g1(32,18)=(-y(43));
g1(32,19)=(-(y(17)*y(44)));
g1(32,22)=(-(y(48)*y(49)*y(15)))/(y(22)*y(22))+(-(params(4)*y(15)))/(y(22)*y(22));
g1(32,38)=(-y(43));
g1(32,43)=(-(y(18)+y(38)));
g1(32,44)=(-(y(17)*y(19)));
g1(32,45)=1;
g1(32,46)=(-1);
g1(32,15)=params(4)/y(22)+y(48)*y(49)/y(22);
g1(32,47)=(-1);
g1(32,48)=y(49)*y(15)/y(22);
g1(32,49)=y(48)*y(15)/y(22);
g1(33,24)=(-(y(2)*y(10)));
g1(33,2)=(-(y(24)*y(10)));
g1(33,5)=y(6);
g1(33,6)=y(5);
g1(33,10)=(-(y(24)*y(2)));
g1(33,46)=1;
g1(33,47)=(-(y(49)*y(16)));
g1(33,16)=(-(y(47)*y(49)));
g1(33,49)=(-(y(47)*y(16)));
g1(34,18)=(-1);
g1(34,38)=(-1);
g1(34,50)=1;
g1(35,21)=1;
g1(35,55)=(-1);
g1(35,51)=1;

end
