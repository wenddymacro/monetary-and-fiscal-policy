function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
% function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = FENKFP_nonlinear_zlb.dynamic_resid_tt(T, y, x, params, steady_state, it_);
end
residual = zeros(35, 1);
lhs = params(9)*y(17)^params(11);
rhs = T(1)*T(2);
residual(1) = lhs - rhs;
lhs = y(20);
rhs = T(3)*T(4);
residual(2) = lhs - rhs;
lhs = 1;
rhs = y(21)*y(52)/y(53);
residual(3) = lhs - rhs;
lhs = y(23);
rhs = T(5)*T(6);
residual(4) = lhs - rhs;
lhs = 1;
rhs = y(55)*y(54)/y(53);
residual(5) = lhs - rhs;
lhs = y(24);
rhs = (1+params(4)*y(25))/y(2);
residual(6) = lhs - rhs;
lhs = y(25)*y(26);
rhs = y(27)*params(36);
residual(7) = lhs - rhs;
lhs = y(25)*(y(26)-params(4)*y(3)/y(22))+y(28);
rhs = params(36)+y(29);
residual(8) = lhs - rhs;
lhs = T(7)*(y(55)-y(21));
rhs = y(30);
residual(9) = lhs - rhs;
residual(10) = T(7)*(y(31)-y(21));
lhs = y(32);
rhs = params(12)/(params(12)-1)*y(33)/y(34);
residual(11) = lhs - rhs;
lhs = y(33);
rhs = y(35)*y(36)+y(52)*params(13)*T(8)*y(56);
residual(12) = lhs - rhs;
lhs = y(34);
rhs = y(36)+y(52)*params(13)*T(9)*y(57);
residual(13) = lhs - rhs;
lhs = y(19);
rhs = y(35)*y(37);
residual(14) = lhs - rhs;
lhs = y(18)+y(38)+y(45);
rhs = y(36);
residual(15) = lhs - rhs;
lhs = y(36)*y(39);
rhs = y(17)*y(37);
residual(16) = lhs - rhs;
lhs = y(39);
rhs = (1-params(13))*y(32)^(-params(12))+T(10)*y(9);
residual(17) = lhs - rhs;
lhs = 1;
rhs = (1-params(13))*y(32)^(1-params(12))+params(13)*y(22)^(params(12)-1);
residual(18) = lhs - rhs;
lhs = y(48)*y(47)+y(25)*y(10);
rhs = y(28);
residual(19) = lhs - rhs;
lhs = y(49);
rhs = (1+params(4)*y(48))/y(16);
residual(20) = lhs - rhs;
lhs = y(58);
rhs = y(31);
residual(21) = lhs - rhs;
lhs = y(41);
rhs = y(26)+y(40);
residual(22) = lhs - rhs;
lhs = y(38);
rhs = y(25)*y(41);
residual(23) = lhs - rhs;
lhs = log(y(42));
rhs = (1-params(21))*log(params(19))+params(21)*log(y(11))+x(it_, 4);
residual(24) = lhs - rhs;
lhs = log(y(37));
rhs = (1-params(22))*log(params(8))+params(22)*log(y(7))+x(it_, 3);
residual(25) = lhs - rhs;
lhs = log(y(27));
rhs = (1-params(20))*log(params(18))+params(20)*log(y(4))+x(it_, 2);
residual(26) = lhs - rhs;
lhs = y(31);
rhs = params(23)*y(6)+(1-params(23))*((steady_state(15))+params(24)*(y(22)-params(1))+params(25)*(y(36)-(steady_state(20))))+x(it_, 1);
residual(27) = lhs - rhs;
lhs = y(42);
rhs = y(28);
residual(28) = lhs - rhs;
lhs = y(43);
rhs = (1-params(16))*params(14)+y(12)*params(16)+x(it_, 5);
residual(29) = lhs - rhs;
lhs = y(44);
rhs = (1-params(17))*params(15)+params(17)*y(13)+(1-params(17))*params(35)*(y(17)*y(19)-(steady_state(3))*(steady_state(1)))+x(it_, 6);
residual(30) = lhs - rhs;
lhs = log(y(45));
rhs = (1-params(5))*log(y(36)*params(6))+params(5)*log(y(14))+x(it_, 7);
residual(31) = lhs - rhs;
lhs = y(45)+y(48)*y(49)*y(15)/y(22);
rhs = y(47)+y(43)*(y(18)+y(38))+y(17)*y(44)*y(19)-params(4)*y(15)/y(22)+y(46);
residual(32) = lhs - rhs;
lhs = y(46);
rhs = y(47)*y(49)*y(16)+y(10)*y(24)*y(2)-y(6)*y(5);
residual(33) = lhs - rhs;
lhs = y(50);
rhs = y(18)+y(38);
residual(34) = lhs - rhs;
lhs = y(51);
rhs = y(55)-y(21);
residual(35) = lhs - rhs;

end
